create database testesa;
use testesa;

create table usuarios(
    id_usuario int not null AUTO_INCREMENT,
    nome_usuario varchar(100) not null,
    senha varchar(100) not null,
    email varchar(150) not null,
    primary key(id_usuario)
)

create table questoes(
    id_questoes int not null AUTO_INCREMENT,
    texto_questao varchar(100) not null,
    primary key(id_questoes)
);


insert into questoes(texto_questao) values("Qual método HTTP é normalmente usado para criar um novo recurso em uma API REST?");
insert into questoes(texto_questao) values("Em HTML, qual é a tag utilizada quando se criam títulos?");

insert into questoes(texto_questao) values("No CSS, qual propriedade altera a margem de um elemento?");
insert into questoes(texto_questao) values("Qual comando SQL é usado para atualizar dados em uma tabela existente?");
insert into questoes(texto_questao) values("No Node.js, qual função é usada para criar um servidor HTTP?");
insert into questoes(texto_questao) values("Qual é a principal função do framework Express?");
insert into questoes(texto_questao) values("O que significa a sigla CRUD?");
insert into questoes(texto_questao) values("Como você converte um objeto JavaScript em uma string JSON?");
insert into questoes(texto_questao) values("Qual é a estrutura correta para uma declaração de rota em Express para uma requisição GET?");
insert into questoes(texto_questao) values("Em SQL, qual cláusula é usada para filtrar resultados em uma consulta?");
select * from questoes;


create table alternativas(
    id_alternativas int not null AUTO_INCREMENT,
    id_questoes int not null,
    texto_alternativa varchar(200) not null,
    questao_certa TINYINT(1) not null,
    PRIMARY KEY(id_alternativas),
    Foreign Key (id_questoes) REFERENCES questoes(id_questoes)
)

select * from alternativas;

--Questão 1(0 = errado, 1 = certa)
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(1, "GET", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(1, "POST", 1);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(1, "PUT", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(1, "DELETE", 0);

select * from alternativas;
--Questão 2
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(2, "h1", 1);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(2, "p", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(2, "img", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(2, "li", 0);

--Questão 3
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(3, "padding", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(3, "border", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(3, "margin", 1);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(3, "spacing", 0);

--Questão 4
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(4, "MODIFY", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(4, "CHANGE", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(4, "UPDATE", 1);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(4, "ALTER", 0);

--Questão 5
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(5, "http.createServer()", 1);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(5, "http.startServer()", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(5, "http.listen()", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(5, "http.run()", 0);

--Questão 6
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(6, "Manipular o banco de dados", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(6, "Facilitar a criação de servidores e APIs em Node.js", 1);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(6, "Estilizar páginas HTML", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(6, "Analisar dados em JSON", 0);

--Questão 7
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(7, "Create, Read, Update, Delete", 1);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(7, "Create, Retrieve, Upload, Download", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(7, "Copy, Remove, Update, Delete", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(7, "Create, Replace, Update, Delete", 0);

--Questão 8
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(8, "JSON.stringify()", 1);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(8, "JSON.parse()", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(8, "JSON.toString()", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(8, "JSON.object()", 0);


--Questão 9
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(9, "app.get('/route', (req, res) => {...}))", 1);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(9, "app.route('/route', (req, res) => {...})", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(9, "app.POST('/route', (req, res) => {...})", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(9, "app.get('/route') => {...}", 0);

--Questão 10
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(10, "FILTER", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(10, "WHERE", 1);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(10, "HAVING", 0);
insert into alternativas(id_questoes, texto_alternativa, questao_certa) values(10, "SELECT", 0);

select * from alternativas;

create table respostas(
    id_respostas int not null AUTO_INCREMENT,
    id_alternativas int not null,
    id_questoes int not null,
    primary key(id_respostas),
    Foreign Key (id_alternativas) REFERENCES alternativas(id_alternativas),
    Foreign Key (id_questoes) REFERENCES questoes(id_questoes)
)

--Questão 1(questao x, alternativa correta y)
insert into respostas(id_questoes, id_alternativas) values(1, 2)

--Questão 2
insert into respostas(id_questoes, id_alternativas) values(2, 5)

--Questão 3
insert into respostas(id_questoes, id_alternativas) values(3, 11)

--Questão 4
insert into respostas(id_questoes, id_alternativas) values(4, 15)

--Questão 5
insert into respostas(id_questoes, id_alternativas) values(5, 17)

--Questão 6
insert into respostas(id_questoes, id_alternativas) values(6, 22)

--Questão 7
insert into respostas(id_questoes, id_alternativas) values(7, 25)

--Questão 8
insert into respostas(id_questoes, id_alternativas) values(8, 29)

--Questão 9
insert into respostas(id_questoes, id_alternativas) values(9, 33)

--Questão 10
insert into respostas(id_questoes, id_alternativas) values(10, 38)



create table resultado(
    id_resultado int not null AUTO_INCREMENT,
    qtd_acertos int not null,
    qtd_erros int not null,
    id_questaoCerta varchar(100) not null,
    data_hora varchar(200) not null,
    primary key(id_resultado)
)

drop table resultado

