import Crud from '../mvc/crud.js'
//import Crud from '../mvc/Crud'
import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url';
import bodyParser from 'body-parser';

// Necessário para obter __dirname em ES Modules
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
const router = express.Router()
const views = '../testesa/views';

//Instância da classe - funciona como prototype
const crud = new Crud()

// Configurar o body-parser para dados JSON
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('views'))


//Pagina de cadastro
app.get('/', function(req, res){
    res.sendFile('cadastro.html', {root: views});
})

app.post('/inserir', function(req, res){
    const { nome_usuario, senha, email } = req.body;
    const usuario = {"nome_usuario":nome_usuario,"senha":senha,"email":email};
    const usuarioStr = JSON.stringify(usuario);

    //Verificando se já existem usuarios com tal email
    crud.selecionarUsuarioEmail(email, function(r){
        //Caso existe um usuario com esse email, retornará erro
        r.length >= 1 ? res.redirect("/erroEmail") : adicionaUsuario();
    })

    //Criando uma funcao que adicionará o usuário ao BD
    const adicionaUsuario = () => {
        crud.insertUsuario(usuario, function(usuarios){
        //Adicionando um localStorage para realizar verificacao de login
        res.send(`<script>localStorage.setItem('usuario', ${ JSON.stringify(usuarioStr) });
            setTimeout(() =>{
                window.location.replace('../index')
            }, 1500)
            </script>`)
        })
    }
})

app.get("/erroEmail", function(req, res){
    res.send("<p>Erro! Email inválido. Insira outro email e tente novamente</p><br><form method='GET' action='/'><input type='submit' value='Ok'></form>");
})

//Página inicial do projeto
app.get("/index", function(req, res){
    crud.selecionarQuestoes(function(q){
        crud.selecionarAlternativas(function(a){

            const mathRandom1 = Math.random();
            const mathRandom2 = Math.random();

            //Criando questões embaralhadas
            const questoesE = [];
            for(let i = 0; i < q.length; i++){
                questoesE.push(q[i]);
            }

            const alternativasA = [];
            for(let i = 0; i < a.length; i++){
                alternativasA.push(a[i]);
            }

            //Questões embaralhadas
            const qe = JSON.stringify(questoesE.sort(() => mathRandom1 - mathRandom2));
            //Alternativas embaralhadas
            const ae = JSON.stringify(alternativasA.sort(() => mathRandom1 - mathRandom2))
            crud.selecionarCertas(function(x){
                res.send(`<h1>Bem vindo a página de perguntas!</h1>
                    <p>Aqui você poderá ver e responder as perguntas, enumeradas de 0 a 10 e embaralhadas. Boa sorte!</p>
                    <script>
                    const logado = JSON.parse(localStorage.getItem('usuario'));
                    if(!logado){
                        alert('Se logue primeiro!');
                        setTimeout(() =>{
                            window.location.replace('../')
                        }, 500)
                    }
                    </script>
                    <form method = "GET" action="/incluirResposta" id="form-quiz" style="display: flex; flex-direction: column; flex-wrap: wrap; max-width: 600px; margin: 0 auto;">
                    <div class="container">
                    <h3 class="covarde"></h3>
                            <label class="alternativa"><input type="radio" class="input" name="q1"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q1"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q1"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q1"></label>
                    </div>
                    <div class="container">
                    <h3 class="covarde"></h3>
                            <label class="alternativa"><input type="radio" class="input" name="q2"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q2"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q2"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q2"></label>
                    </div>
                    <div class="container">
                    <h3 class="covarde"></h3>
                            <label class="alternativa"><input type="radio" class="input" name="q3"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q3"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q3"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q3"></label>
                    </div>
                    <div class="container">
                    <h3 class="covarde"></h3>
                            <label class="alternativa"><input type="radio" class="input" name="q4"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q4"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q4"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q4"></label>
                    </div>
                    <div class="container">
                    <h3 class="covarde"></h3>
                            <label class="alternativa"><input type="radio" class="input" name="q5"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q5"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q5"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q5"></label>
                    </div>
                    <div class="container">
                    <h3 class="covarde"></h3>
                            <label class="alternativa"><input type="radio" class="input" name="q6"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q6"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q6"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q6"></label>
                    </div>
                    <div class="container">
                    <h3 class="covarde"></h3>
                            <label class="alternativa"><input type="radio" class="input" name="q7"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q7"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q7"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q7"></label>
                    </div>
                    <div class="container">
                    <h3 class="covarde"></h3>
                            <label class="alternativa"><input type="radio" class="input" name="q8"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q8"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q8"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q8"></label>
                    </div>
                    <div class="container">
                    <h3 class="covarde"></h3>
                            <label class="alternativa"><input type="radio" class="input" name="q9"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q9"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q9"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q9"></label>
                    </div>
                    <div class="container">
                    <h3 class="covarde"></h3>
                            <label class="alternativa"><input type="radio" class="input" name="q10"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q10"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q10"></label>
                            <label class="alternativa"><input type="radio" class="input" name="q10"></label>
                    </div>
    
                            <input type="submit" value="Enviar" id="botao-form">
                    </form>
                    <div>
                        <form method="POST" action="/incluirResposta" id="form-submit">
                            <input type="text" name="resposta" id="resposta">
                        </form>
                    </div>
                    <script>
                    var f = 0;
                    var m = 0;
                    const p = document.getElementsByClassName('covarde');
                    const input = document.getElementsByClassName("input");
                    const b = document.getElementsByClassName('alternativa');
                    
                    //looping para percorrer todas as 10 questões
                    for(let i = 0; i < ${q.length}; i++){
                        p[i].innerHTML += ${qe}[i].texto_questao;
                        
                        //Para cada questão, é percorrido um looping para trazer as 4 alternativas
                        for(let j = 0; j < 4; j++){
                            b[f].innerHTML += ${ae}[f].texto_alternativa;
                            input[f].value = ${ae}[f].id_alternativas;
    
                            //Adicionando o evento a todos os inputs
                            input[f].addEventListener("click", function(){
                                const input = document.getElementsByClassName("input");
                                const titulo = document.getElementsByClassName("covarde");
    
                                this.setAttribute("disable", true);
                                this.classList.add("alternativa-escolhida");
                            })
                            f += 1;
                        };
                    }
    
                    //Adicionando o evento
                    const form = document.getElementById('form-quiz');
                    form.addEventListener("submit", function(e){
                        let score = 0;
                        var alternativaEscolhida = document.getElementsByClassName('alternativa-escolhida');
                        var alternativas = [];
                        console.log(alternativaEscolhida[0].value)
                        e.preventDefault();
                        for(let i = 0; i < alternativaEscolhida.length; i++){
                                if(alternativaEscolhida[i].value == ${x[0].id_alternativas} || alternativaEscolhida[i].value == ${x[1].id_alternativas} || alternativaEscolhida[i].value == ${x[2].id_alternativas} || alternativaEscolhida[i].value == ${x[3].id_alternativas} || alternativaEscolhida[i].value == ${x[4].id_alternativas} || alternativaEscolhida[i].value == ${x[5].id_alternativas} || alternativaEscolhida[i].value == ${x[6].id_alternativas} || alternativaEscolhida[i].value == ${x[7].id_alternativas} || alternativaEscolhida[i].value == ${x[8].id_alternativas} || alternativaEscolhida[i].value == ${x[9].id_alternativas}){
                                    console.log("OK");
                                    score++;
                                    alternativas.push(alternativaEscolhida[i].value)
                                }else{
                                    alternativas.push(alternativaEscolhida[i].value)
                                    console.log("NOT OK");
                                //Fim looping J
                                }
                        }
                        if(score >= 7){
                            alert("Você acertou " + score + " questões, parabéns! Nota mínima atingida com sucesso");
                            const tempo = new Date();
                            const resultado = {"qtd_acertos": score, "qtd_erros": 10 - score, "id_questaoCerta": alternativas, "data_hora": tempo.toString()};
                            const resultadoStr = JSON.stringify(resultado);
                            const resultadoInput = document.getElementById('resposta');
                            resultadoInput.value = resultadoStr;
                            
                            const formSubmit = document.getElementById('form-submit');
                            console.log(formSubmit);
                            formSubmit.submit();
        
                            localStorage.setItem('resultado', resultadoStr);
                        }else{
                            alert("Você acertou " + score + " questões e infelizmente não atingiu a nota mínima de 7. Tente novamente")
                            location.reload()
                        }
                });
                    </script>

                    <!--Adicionando um botao para visualizar os últimos 5 resultados do usuario-->
                    <form action="/visualizarResultados" method="GET" style="display: flex; justify-content: center; align-items: center;">
                        <input type="submit" id="botao-form" class="botao-form-resultados" value="Ver últimos resultados"/>
                    </form> 

                    <style>h1, p{text-align:center;}
                    .covarde{display: flex; flex-direction: column-reverse; margin-top: 0;}
                    #form-quiz{display: flex; flex-direction: row; flex-wrap: wrap; row-gap: 1rem;}
                    .container{display: flex; justify-content: center; flex-direction: column; border: 1px solid #CCC; border-radius: 20px; padding: 1rem 1.5rem; box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px; -webkit-box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;} 
                    #botao-form{background-color: rgb(255, 200, 2); font-size: 14px; text-transform: uppercase; font-weight: bold; font-family: 'Inter', sans-serif; max-width: 150px; height: 40px; border: 0; border-radius: 15px; transition: all ease-in-out .5s} #botao-form:hover{cursor: pointer; color: #FFF; transform: scale(1.1) translateY(-10px); margin-top: 10px;}
                    #form-submit{display: none} .botao-form-resultados{max-width: unset !important; padding: .8rem 1rem !important};
                    </style>
                    `);
            })     
        })
    });
})

app.post("/incluirResposta", function(req, res){
    const { resposta } = req.body;
    const arrResposta = JSON.parse(resposta);
    const resultado = {"qtd_acertos": arrResposta.qtd_acertos, "qtd_erros": arrResposta.qtd_erros, "id_questaoCerta": `${arrResposta.id_questaoCerta}`, "data_hora": arrResposta.data_hora}
    crud.inserirResultado(resultado, function(x){
        console.log("TUDO OK!");
    })
    res.redirect('/index');
})

app.get("/visualizarResultados", function(req, res){
    crud.visualizarResultado(function(resultado){
        res.send(
            `<div class="container">
                <h1>Resultados: </h1>
            </div>
            <form method="GET" action="/index" class="formulario-voltar">
                <input type="submit" value="voltar"/>
            </form>
            <script>
                const container = document.getElementsByClassName('container')[0];
                const resultados = [];  
                for(let i = 0; i < ${ resultado.length }; i++){
                    var acertos = document.createElement("p")
                    var erros = document.createElement("p")
                    var data = document.createElement("p")
                    var containerUsuario = document.createElement("div");
                    

                    resultados.push(${ JSON.stringify(resultado)}[i]);
                    acertos.innerText = "Acertos: " + JSON.stringify(resultados[i].qtd_acertos);
                    erros.innerText = "Erros: " + JSON.stringify(resultados[i].qtd_erros);
                    data.innerText = "Data: " + JSON.stringify(resultados[i].data_hora);
        

                    acertos.classList.add('resultado');
                    erros.classList.add('resultado');
                    data.classList.add('resultado');
                    containerUsuario.classList.add("container-usuario");


                    containerUsuario.append(acertos, erros, data);
                    container.appendChild(containerUsuario);
                }
            </script>
            <style>
            h1{text-align: center;}.container-usuario{display: flex; justify-content: space-around; align-items: center; column-gap: .8rem;}.container{width: fit-content; margin: 0 auto; border: 1px solid #CCC; border-radius: 20px; padding: 1rem 1.5rem; box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px; -webkit-box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;}.formulario-voltar input{width: 150px;background-color: rgb(255, 200, 2); font-size: 14px; text-transform: uppercase; font-weight: bold; font-family: 'Inter', sans-serif; height: 40px; border: 0; border-radius: 15px; transition: all ease-in-out .5s; margin-top: 2rem;} .formulario-voltar input:hover{cursor: pointer; color: #FFF; transform: scale(1.1) translateY(-10px);}.formulario-voltar{display: flex; justify-content: center;}
            </style>
            `
        )
    })
})

const server = app.listen(3000, function(){
    let host = server.address().host;
    let port = server.address().port;
    console.log("Servidor iniciado em " + port);
})