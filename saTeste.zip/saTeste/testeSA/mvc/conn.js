import mysql from 'mysql2'

//Criando a conexão com o banco de dados
const conn = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "fatec123",
    database: "testesa"
})

conn.connect()
export default conn