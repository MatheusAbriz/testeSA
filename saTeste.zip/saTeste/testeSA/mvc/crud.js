import conn from './conn.js'

//Classe com todos os CRUDS, tanto de usuarios como de respostas/questoes
class Crud{
    //Funcao de inserir usuario
    insertUsuario(usuario, callback){
        let sql = "insert into usuarios set ?"
        conn.query(sql, usuario, function(error, results, fields){
            if(error) throw error
            //Criando também um localStorage que o usuario irá responder as perguntas somente se estiver logado
            callback(results)
        })
    }

    //Selecionar usuario
    selecionarUsuario(callback){
        let sql = "select * from usuarios";
        conn.query(sql, function(error, results, fields){
            if(error) throw error;
            callback(results)
        })
    }

    //Seleciona usuario pelo email
    selecionarUsuarioEmail(email, callback){
        const sql = `select * from usuarios where email = '${ email }'`
        conn.query(sql, function(error, results, fields){
            if(error) throw error;
            callback(results);
        })
    }

    //Seleciona e retorna as questões
    selecionarQuestoes(callback){
        let sql = "select * from questoes";
        conn.query(sql, function(error, results, fields){
            if(error) throw error;
            callback(results);
        })
    }

    //Seleciona e retorna as alternativas
    selecionarAlternativas(callback){
        let sql = "select * from alternativas";
        conn.query(sql, function(error, results, fields){
            if(error) throw error;
            callback(results);
        })
    }

    //Seleciona e retorna as questoes certas
    selecionarCertas(callback){
        let sql = "select id_alternativas from alternativas where questao_certa = 1";
        conn.query(sql, function(error, results, fields){
            if(error) throw error;
            callback(results);
        })
    }

    //Insere os resultados no banco de dados
    inserirResultado(resultado, callback){
        let sql = "insert into resultado set ?"
        conn.query(sql, resultado, function(error, results, fields){
            if(error) throw error;
            callback(results);
        })
    }

    //Visualiza os resultados do BD
    visualizarResultado(callback){
        let sql = "select qtd_acertos, qtd_erros, data_hora from resultado"
        conn.query(sql, function(error, results, fields){
            if(error) throw error;
            callback(results);
        })
    }
}

export default Crud;